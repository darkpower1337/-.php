<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ManualController;
use App\Http\Controllers\AuthController;

// Главная
Route::get('/', [ManualController::class, 'index'])->name('home');

// Авторизация
Route::get('/login', [AuthController::class, 'showLogin'])->name('login');
Route::post('/login', [AuthController::class, 'login']);

// ВОТ ЗДЕСЬ БЫЛА ОШИБКА! Теперь регистрация вызывает метод register
Route::get('/register', [AuthController::class, 'showRegister'])->name('register');
Route::post('/register', [AuthController::class, 'register']); 

Route::post('/logout', [AuthController::class, 'logout'])->name('logout');

// Личный кабинет (только для вошедших)
Route::middleware('auth')->group(function () {
    Route::get('/dashboard', [ManualController::class, 'dashboard'])->name('dashboard');
    Route::post('/upload', [ManualController::class, 'store'])->name('upload');
    Route::get('/admin/approve/{id}', [ManualController::class, 'approve'])->name('admin.approve');
    Route::get('/admin/delete/{id}', [ManualController::class, 'delete'])->name('admin.delete');
});