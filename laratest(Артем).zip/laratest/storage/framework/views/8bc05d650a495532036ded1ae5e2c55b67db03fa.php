<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Инструкции</title>
    <style>
        * { box-sizing: border-box; font-family: 'Segoe UI', Tahoma, sans-serif; }
        body { background-color: #121212; margin: 0; padding: 20px; color: #e0e0e0; }
        .container { max-width: 900px; margin: 0 auto; background: #1e1e1e; padding: 30px; border-radius: 10px; box-shadow: 0 4px 20px rgba(0,0,0,0.5); }
        h1 { color: #ffffff; border-bottom: 2px solid #bb86fc; padding-bottom: 10px; margin-top: 0; }
        .nav-links { margin-bottom: 20px; background: #2d2d2d; padding: 15px; border-radius: 8px; display: flex; justify-content: space-between; }
        .nav-links a { color: #bb86fc; text-decoration: none; font-weight: bold; }
        .nav-links a:hover { color: #fff; }
        .search-box { display: flex; gap: 10px; margin-bottom: 25px; }
        .search-box input { flex-grow: 1; padding: 10px; background: #2d2d2d; border: 1px solid #444; border-radius: 5px; color: #fff; outline: none; }
        .search-box input:focus { border-color: #bb86fc; }
        button { background: #bb86fc; color: #121212; border: none; padding: 10px 20px; border-radius: 5px; cursor: pointer; font-weight: bold; transition: 0.3s; }
        button:hover { background: #9a66d6; }
        ul { list-style-type: none; padding: 0; }
        li { background: #2d2d2d; margin-bottom: 10px; padding: 15px; border-radius: 5px; display: flex; justify-content: space-between; align-items: center; border-left: 4px solid #bb86fc; }
        li a { background: #03dac6; color: #121212; text-decoration: none; padding: 8px 15px; border-radius: 5px; font-size: 14px; font-weight: bold; transition: 0.3s; }
        li a:hover { background: #01a896; }
    </style>
</head>
<body>
    <div class="container">
        <div class="nav-links">
            <div>
                <?php if(auth()->guard()->check()): ?>
                    <strong>Привет, <?php echo e(Auth::user()->name); ?>!</strong>
                <?php endif; ?>
            </div>
            <div>
                <?php if(auth()->guard()->check()): ?>
                    <a href="<?php echo e(url('/dashboard')); ?>">Личный кабинет</a>
                    <form action="<?php echo e(url('/logout')); ?>" method="POST" style="display:inline;">
                        <?php echo csrf_field(); ?>
                        <button type="submit" style="background:none; border:none; color:#bb86fc; padding:0; cursor:pointer; font-weight:bold; margin-left: 15px;">Выйти</button>
                    </form>
                <?php else: ?>
                    <a href="<?php echo e(url('/login')); ?>">Вход</a>
                    <a href="<?php echo e(url('/register')); ?>" style="margin-left: 15px;">Регистрация</a>
                <?php endif; ?>
            </div>
        </div>

        <h1>Инструкции для техники</h1>

        <form class="search-box" action="<?php echo e(url('/')); ?>" method="GET">
            <input type="text" name="search" placeholder="Поиск по названию..." value="<?php echo e(request('search')); ?>">
            <button type="submit">Найти</button>
        </form>

        <?php if(count($manuals) > 0): ?>
            <ul>
                <?php $__currentLoopData = $manuals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <span><?php echo e($m->title); ?></span>
                        <!-- Ссылка на скачивание из storage -->
                        <a href="<?php echo e(asset('storage/' . $m->file_path)); ?>" download>Скачать</a>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        <?php else: ?>
            <p style="text-align: center; color: #888;">Ничего не найдено.</p>
        <?php endif; ?>
    </div>
</body>
</html><?php /**PATH C:\OSPanel\domains\localhost\laratest\resources\views/home.blade.php ENDPATH**/ ?>