<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Личный кабинет</title>
    <style>
        * { box-sizing: border-box; font-family: 'Segoe UI', Tahoma, sans-serif; }
        body { background-color: #121212; margin: 0; padding: 20px; color: #e0e0e0; }
        .container { max-width: 900px; margin: 0 auto; background: #1e1e1e; padding: 30px; border-radius: 10px; box-shadow: 0 4px 20px rgba(0,0,0,0.5); }
        h2, h3 { color: #fff; border-bottom: 2px solid #bb86fc; padding-bottom: 10px; }
        .nav-links { margin-bottom: 25px; background: #2d2d2d; padding: 15px; border-radius: 8px; display: flex; justify-content: space-between;}
        .nav-links a { color: #bb86fc; text-decoration: none; font-weight: bold; }
        .nav-links a:hover { color: #fff; }
        .upload-form { background: #252525; padding: 20px; border-radius: 8px; border: 1px solid #333; margin-bottom: 30px; }
        input[type="text"], input[type="file"] { width: 100%; padding: 10px; margin-bottom: 15px; background: #2d2d2d; border: 1px solid #444; border-radius: 5px; color: #fff; }
        button { background: #bb86fc; color: #121212; border: none; padding: 10px 20px; border-radius: 5px; cursor: pointer; font-weight: bold; }
        button:hover { background: #9a66d6; }
        .success-msg { background: #03dac6; color: #121212; padding: 15px; border-radius: 5px; margin-bottom: 20px; font-weight: bold; }
        table { width: 100%; border-collapse: collapse; margin-top: 15px; }
        th, td { padding: 12px; text-align: left; border-bottom: 1px solid #333; }
        th { background-color: #2d2d2d; color: #bb86fc; }
        tr:hover { background-color: #252525; }
        .badge { padding: 4px 8px; border-radius: 4px; font-size: 12px; font-weight: bold; }
        .badge-pending { background: #f1c40f; color: #121212; }
        .badge-approved { background: #03dac6; color: #121212; }
        .btn-approve { color: #03dac6; text-decoration: none; font-weight: bold; margin-right: 10px; }
        .btn-delete { color: #cf6679; text-decoration: none; font-weight: bold; }
    </style>
</head>
<body>
    <div class="container">
        <div class="nav-links">
            <a href="<?php echo e(url('/')); ?>">&larr; На главную</a>
            <form action="<?php echo e(url('/logout')); ?>" method="POST" style="margin:0;">
                <?php echo csrf_field(); ?>
                <button type="submit" style="background:none; border:none; color:#bb86fc; padding:0; cursor:pointer; font-weight:bold;">Выйти</button>
            </form>
        </div>

        <?php if(session('success')): ?>
            <div class="success-msg"><?php echo e(session('success')); ?></div>
        <?php endif; ?>

        <h2>Загрузить новую инструкцию</h2>
        <div class="upload-form">
            <form action="<?php echo e(url('/upload')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <input type="text" name="title" placeholder="Название прибора" required>
                <input type="file" name="file" required>
                <button type="submit">Отправить на проверку</button>
            </form>
        </div>

        <?php if(Auth::user()->is_admin): ?>
            <h2>Панель управления (Админ)</h2>
            <table>
                <thead>
                    <tr>
                        <th>Название</th>
                        <th>Статус</th>
                        <th>Действия</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = \App\Models\Manual::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($m->title); ?></td>
                            <td>
                                <?php if($m->status == 'pending'): ?>
                                    <span class="badge badge-pending">На проверке</span>
                                <?php else: ?>
                                    <span class="badge badge-approved">Одобрено</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($m->status == 'pending'): ?>
                                    <a href="<?php echo e(url('/admin/approve/'.$m->id)); ?>" class="btn-approve">Одобрить</a>
                                <?php endif; ?>
                                <a href="<?php echo e(url('/admin/delete/'.$m->id)); ?>" onclick="return confirm('Удалить инструкцию?');" class="btn-delete">Удалить</a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</body>
</html><?php /**PATH C:\OSPanel\domains\localhost\laratest\resources\views/dashboard.blade.php ENDPATH**/ ?>