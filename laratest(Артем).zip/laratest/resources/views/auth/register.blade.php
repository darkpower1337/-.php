<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <style>
        body { background: #121212; color: #fff; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; font-family: sans-serif; }
        .card { background: #1e1e1e; padding: 30px; border-radius: 10px; width: 300px; box-shadow: 0 4px 20px rgba(0,0,0,0.5); }
        input { width: 100%; padding: 10px; margin-bottom: 15px; background: #2d2d2d; border: 1px solid #444; border-radius: 5px; color: #fff; box-sizing: border-box; }
        button { width: 100%; padding: 10px; background: #bb86fc; color: #121212; border: none; border-radius: 5px; font-weight: bold; cursor: pointer; }
        a { color: #bb86fc; text-decoration: none; display: block; text-align: center; margin-top: 15px; }
        .error { color: #cf6679; font-size: 14px; margin-bottom: 10px; }
    </style>
</head>
<body>
    <div class="card">
        <h2 style="text-align:center; margin-top:0;">Регистрация</h2>
        @if ($errors->any())
            <div class="error">
                <ul style="padding-left: 15px; margin: 0;">
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif
        <form action="{{ url('/register') }}" method="POST">
            @csrf
            <input type="text" name="name" placeholder="Имя" required>
            <input type="email" name="email" placeholder="Email" required>
            <input type="password" name="password" placeholder="Пароль" required>
            <input type="password" name="password_confirmation" placeholder="Повторите пароль" required>
            <button type="submit">Зарегистрироваться</button>
        </form>
        <a href="{{ url('/login') }}">Уже есть аккаунт? Войти</a>
    </div>
</body>
</html>