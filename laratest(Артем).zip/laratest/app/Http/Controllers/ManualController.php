<?php
namespace App\Http\Controllers;
use App\Models\Manual;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Auth;

class ManualController extends Controller
{
    public function index(Request $request) {
        $manuals = Manual::where('status', 'approved')->where('title', 'LIKE', '%'.$request->search.'%')->get();
        return view('home', compact('manuals'));
    }
    public function dashboard() { return view('dashboard'); }
    public function store(Request $request) {
        $path = $request->file('file')->store('uploads', 'public');
        Manual::create(['title' => $request->title, 'file_path' => $path, 'status' => 'pending']);
        return back()->with('success', 'Загружено!');
    }
    public function approve($id) {
        if (Auth::user()->is_admin) Manual::where('id', $id)->update(['status' => 'approved']);
        return back();
    }
    public function delete($id) {
        if (Auth::user()->is_admin) {
            $m = Manual::find($id); Storage::disk('public')->delete($m->file_path); $m->delete();
        }
        return back();
    }
}