<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

class AuthController extends Controller
{
    public function showLogin()
    {
        return view('auth.login');
    }

    public function login(Request $request)
    {
        if (Auth::attempt($request->only('email', 'password'))) {
            return redirect('/dashboard');
        }
        return back()->with('error', 'Неверный логин или пароль');
    }

    public function showRegister()
    {
        return view('auth.register');
    }

    public function register(Request $request)
{
    // ВРЕМЕННО ВЫВОДИМ ВСЕ ОШИБКИ
    $request->validate([
        'name' => 'required',
        'email' => 'required|email|unique:users',
        'password' => 'required|min:6|confirmed'
    ]);

    // Если код дошел сюда, значит валидация ПРОЙДЕНА.
    // Если нет - Laravel вернет на страницу и мы ничего не увидим.

    // Попробуем создать юзера
    try {
        $user = User::create([
            'name' => $request->name,
            'email' => $request->email,
            'password' => Hash::make($request->password)
        ]);

        Auth::login($user);

        // Если всё ок, принудительно редиректим
        return redirect('/dashboard');

    } catch (\Exception $e) {
        // ЕСЛИ БАЗА ДАННЫХ ВЫДАЛА ОШИБКУ - МЫ ЕЕ УВИДИМ!
        dd("ОШИБКА ПРИ СОЗДАНИИ ПОЛЬЗОВАТЕЛЯ:", $e->getMessage());
    }
}

    public function logout()
    {
        Auth::logout();
        return redirect('/');
    }
}